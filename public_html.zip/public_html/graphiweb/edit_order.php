<?php
require '../includes/config.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 1) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $order_id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();
    if (!$order) {
        header("Location: manage_orders.php");
        exit();
    }
}

$users = $pdo->query("SELECT id, name FROM users")->fetchAll();
$cakes = $pdo->query("SELECT id, name FROM cakes")->fetchAll();
$branches = $pdo->query("SELECT id, name FROM branches")->fetchAll();

if (isset($_POST['edit_order'])) {
    $user_id = $_POST['user_id'];
    $cake_id = $_POST['cake_id'];
    $branch_id = $_POST['branch_id'];
    $total_price = $_POST['total_price'];
    $delivery_method = $_POST['delivery_method'];
    $delivery_date = $_POST['delivery_date'];
    $delivery_time = $_POST['delivery_time'];
    $status = $_POST['status'];

    $province = $_POST['province'] ?? '';
    $city = $_POST['city'] ?? '';
    $street_address = $_POST['street_address'] ?? '';
    $house_number = $_POST['house_number'] ?? '';
    $extra_details = $_POST['extra_details'] ?? '';

    $stmt = $pdo->prepare("UPDATE orders SET user_id = ?, cake_id = ?, branch_id = ?, total_price = ?, delivery_method = ?, delivery_date = ?, delivery_time = ?, status = ?, province = ?, city = ?, street_address = ?, house_number = ?, extra_details = ? WHERE id = ?");
    $stmt->execute([
        $user_id, $cake_id, $branch_id, $total_price, $delivery_method,
        $delivery_date, $delivery_time, $status,
        $province, $city, $street_address, $house_number, $extra_details,
        $order_id
    ]);

    header("Location: manage_orders.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        window.addEventListener("DOMContentLoaded", function () {
            const deliveryMethodSelect = document.querySelector('select[name="delivery_method"]');
            const deliveryFields = document.getElementById("delivery-fields");
            const addressFields = document.getElementById("address-fields");

            function showFields(method) {
                if (method.toLowerCase() === 'pickup') {
                    deliveryFields.style.display = "block";
                    addressFields.style.display = "none";
                } else {
                    deliveryFields.style.display = "none";
                    addressFields.style.display = "block";
                }
            }

            // اجرای اولیه
            showFields(deliveryMethodSelect.value);

            // موقع تغییر توسط کاربر
            deliveryMethodSelect.addEventListener("change", function () {
                showFields(this.value);
            });
        });
    </script>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center mb-4">Edit Order</h1>
    <form method="POST">
        <div class="form-group mb-2">
            <label>User</label>
            <select name="user_id" class="form-control" required>
                <option value="">Select User</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?= $user['id'] ?>" <?= $user['id'] == $order['user_id'] ? 'selected' : '' ?>><?= htmlspecialchars($user['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group mb-2">
            <label>Cake</label>
            <select name="cake_id" class="form-control" required>
                <option value="">Select Cake</option>
                <?php foreach ($cakes as $cake): ?>
                    <option value="<?= $cake['id'] ?>" <?= $cake['id'] == $order['cake_id'] ? 'selected' : '' ?>><?= htmlspecialchars($cake['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group mb-2">
            <label>Branch</label>
            <select name="branch_id" class="form-control" required>
                <option value="">Select Branch</option>
                <?php foreach ($branches as $branch): ?>
                    <option value="<?= $branch['id'] ?>" <?= $branch['id'] == $order['branch_id'] ? 'selected' : '' ?>><?= htmlspecialchars($branch['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group mb-2">
            <label>Total Price</label>
            <input type="number" name="total_price" class="form-control" value="<?= $order['total_price'] ?>" required>
        </div>

        <div class="form-group mb-2">
            <label>Delivery Method</label>
            <?php $method = strtolower($order['delivery_method']); ?>
            <select name="delivery_method" class="form-control" required>
                <option value="Pickup" <?= $method === 'pickup' ? 'selected' : '' ?>>Pickup</option>
                <option value="Delivery" <?= $method === 'delivery' ? 'selected' : '' ?>>Delivery</option>
            </select>
        </div>

        <div id="delivery-fields">
            <div class="form-group mb-2">
                <label>Delivery Date</label>
                <input type="date" name="delivery_date" class="form-control" value="<?= $order['delivery_date'] ?>">
            </div>
            <div class="form-group mb-2">
                <label>Delivery Time</label>
                <input type="time" name="delivery_time" class="form-control" value="<?= $order['delivery_time'] ?>">
            </div>
        </div>

        <div class="form-group mb-2">
            <label>Status</label>
            <input type="text" name="status" class="form-control" value="<?= $order['status'] ?>" required>
        </div>

        <div id="address-fields">
            <hr>
            <h4>Delivery Address</h4>
            <div class="form-group mb-2">
                <label>Province</label>
                <input type="text" name="province" class="form-control" value="<?= htmlspecialchars($order['province'] ?? '') ?>">
            </div>
            <div class="form-group mb-2">
                <label>City</label>
                <input type="text" name="city" class="form-control" value="<?= htmlspecialchars($order['city'] ?? '') ?>">
            </div>
            <div class="form-group mb-2">
                <label>Street Address</label>
                <input type="text" name="street_address" class="form-control" value="<?= htmlspecialchars($order['street_address'] ?? '') ?>">
            </div>
            <div class="form-group mb-2">
                <label>House Number</label>
                <input type="text" name="house_number" class="form-control" value="<?= htmlspecialchars($order['house_number'] ?? '') ?>">
            </div>
            <div class="form-group mb-2">
                <label>Additional Details</label>
                <textarea name="extra_details" class="form-control"><?= htmlspecialchars($order['extra_details'] ?? '') ?></textarea>
            </div>
        </div>

        <button type="submit" name="edit_order" class="btn btn-success mt-3">Update Order</button>
    </form>
</div>
</body>
</html>
