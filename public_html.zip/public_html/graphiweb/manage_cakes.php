<?php
require '../includes/config.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 1) {
    header("Location: index.php");
    exit();
}

$stmt = $pdo->prepare("SELECT section FROM permissions WHERE role_id = ?");
$stmt->execute([$_SESSION['role_id']]);
$user_permissions = $stmt->fetchAll(PDO::FETCH_COLUMN);

$current_page = basename($_SERVER['PHP_SELF'], ".php");
$permission_map = [
    'manage_users' => 'manage_users',
    'manage_roles' => 'manage_roles',
    'manage_orders' => 'manage_orders',
    'manage_cakes' => 'manage_cakes',
    'manage_branches' => 'manage_branches',
];

if (!in_array($permission_map[$current_page] ?? '', $user_permissions)) {
    header("Location: index.php?error=no_access");
    exit();
}

$stmt = $pdo->query("SELECT * FROM cakes");
$cakes = $stmt->fetchAll();

if (isset($_POST['delete_cake'])) {
    $cake_id = $_POST['cake_id'];
    $stmt = $pdo->prepare("DELETE FROM cakes WHERE id = ?");
    $stmt->execute([$cake_id]);
    header("Location: manage_cakes.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Cakes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .thumb {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="text-center">Manage Cakes</h1>
        <a href="index.php" class="btn btn-secondary mb-4">Back</a>
        <a href="add_cake.php" class="btn btn-primary mb-4">Add New Cake</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Base Price (€)</th>
                    <th>Pricing Type</th>
                    <th>Price Per Slice (€)</th>
                    <th>Price Half Cake (€)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cakes as $cake): ?>
                    <tr>
                        <td><?= $cake['id'] ?></td>
                        <td>
                            <?php if (!empty($cake['image_url'])): ?>
                                <img src="<?= htmlspecialchars($cake['image_url']) ?>" class="thumb">
                            <?php else: ?>
                                <span>No Image</span>
                            <?php endif; ?>
                        </td>
                        
                        <td><?= htmlspecialchars($cake['name']) ?></td>
                        <td><?= htmlspecialchars($cake['description']) ?></td>
                        <td><?= number_format($cake['base_price'], 2) ?> €</td>
                        <td><?= ($cake['pricing_type'] === 'multi') ? 'Multi-Priced' : 'Single-Priced' ?></td>
                        <td><?= ($cake['pricing_type'] === 'multi') ? number_format($cake['price_per_slice'], 2) . ' €' : 'N/A' ?></td>
                        <td><?= ($cake['pricing_type'] === 'multi') ? number_format($cake['price_half'], 2) . ' €' : 'N/A' ?></td>
                        <td>
                            <form method='POST' style='display:inline;'>
                                <input type='hidden' name='cake_id' value='<?= $cake["id"] ?>'>
                                <button type='submit' name='delete_cake' class='btn btn-sm btn-danger'>Delete</button>
                            </form>
                            <a href='edit_cake.php?id=<?= $cake["id"] ?>' class='btn btn-sm btn-warning'>Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
