<?php
require '../includes/config.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 1) {
    header("Location: index.php");
    exit();
}

// دریافت لیست سفارش‌ها
$stmt = $pdo->query("SELECT * FROM orders");
$orders = $stmt->fetchAll();

// حذف سفارش
if (isset($_POST['delete_order'])) {
    $order_id = $_POST['order_id'];
    $stmt = $pdo->prepare("DELETE FROM orders WHERE id = ?");
    $stmt->execute([$order_id]);
    header("Location: manage_orders.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h1 class="text-center mb-4">Manage Orders</h1>

    <a href="index.php" class="btn btn-secondary mb-3">Back</a>
    <a href="add_order.php" class="btn btn-primary mb-3">Add New Order</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Order Date</th>
                <th>User</th>
                <th>Cake</th>
                <th>Branch</th>
                <th>Total Price</th>
                <th>Delivery Method</th>
                <th>Delivery Date</th>
                <th>Delivery Time</th>
                <th>Province</th>
                <th>City</th>
                <th>Street</th>
                <th>No.</th>
                <th>Extra Details</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($orders as $order): ?>
            <?php
                $stmt = $pdo->prepare("SELECT name FROM users WHERE id = ?");
                $stmt->execute([$order['user_id']]);
                $user = $stmt->fetchColumn() ?: '—';

                $stmt = $pdo->prepare("SELECT name FROM cakes WHERE id = ?");
                $stmt->execute([$order['cake_id']]);
                $cake = $stmt->fetchColumn() ?: '—';

                $stmt = $pdo->prepare("SELECT name FROM branches WHERE id = ?");
                $stmt->execute([$order['branch_id']]);
                $branch = $stmt->fetchColumn() ?: '—';
            ?>
            <tr>
                <td><?= $order['id'] ?></td>
                <td><?= htmlspecialchars($order['order_date']) ?></td>
                <td><?= htmlspecialchars($user) ?></td>
                <td><?= htmlspecialchars($cake) ?></td>
                <td><?= htmlspecialchars($branch) ?></td>
                <td><?= htmlspecialchars($order['total_price']) ?></td>
                <td><?= htmlspecialchars($order['delivery_method']) ?></td>
                <td><?= $order['delivery_date'] ?? '—' ?></td>
                <td><?= $order['delivery_time'] ?? '—' ?></td>
                <td><?= htmlspecialchars($order['province'] ?? '—') ?></td>
                <td><?= htmlspecialchars($order['city'] ?? '—') ?></td>
                <td><?= htmlspecialchars($order['street_address'] ?? '—') ?></td>
                <td><?= htmlspecialchars($order['house_number'] ?? '—') ?></td>
                <td><?= nl2br(htmlspecialchars($order['extra_details'] ?? '—')) ?></td>
                <td><?= htmlspecialchars($order['status']) ?></td>
                <td>
                    <a href="edit_order.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                        <button type="submit" name="delete_order" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
