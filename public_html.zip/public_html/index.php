<?php
require 'includes/config.php';

$cakes = [];
$branch_info = "";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $postal_code = trim($_POST['postal_code']);

    $stmt = $pdo->prepare("SELECT latitude, longitude FROM postal_codes WHERE postal_code = ? LIMIT 1");
    $stmt->execute([$postal_code]);
    $user_location = $stmt->fetch();

    if ($user_location) {
        $stmt = $pdo->prepare("SELECT id, name, address, city, latitude, longitude, 
            ROUND((6371 * ACOS(COS(RADIANS(?)) * COS(RADIANS(latitude)) * 
            COS(RADIANS(longitude) - RADIANS(?)) + SIN(RADIANS(?)) * SIN(RADIANS(latitude)))), 2) AS distance 
            FROM branches ORDER BY distance ASC LIMIT 1");
        $stmt->execute([$user_location['latitude'], $user_location['longitude'], $user_location['latitude']]);
        $branch = $stmt->fetch();

        if ($branch) {
            $branch_info = "<div class='alert alert-info mb-4'><strong>Closest Branch:</strong> {$branch['name']} - {$branch['address']} ({$branch['city']})</div>";

            $stmt = $pdo->prepare("SELECT cakes.* FROM cakes 
                                  JOIN cake_branch ON cakes.id = cake_branch.cake_id 
                                  WHERE cake_branch.branch_id = ?");
            $stmt->execute([$branch['id']]);
            $cakes = $stmt->fetchAll();

            if (!$cakes) {
                $message = "<p class='text-danger'>No cakes found in this branch.</p>";
            }
        } else {
            $message = "<p class='text-danger'>No branches found near this postal code.</p>";
        }
    } else {
        $message = "<p class='text-danger'>Invalid postal code. Please try again.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cake Order Shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .cake-thumbnail {
            height: 180px;
            object-fit: cover;
        }
        .cake-card {
            border-radius: 16px;
            overflow: hidden;
            transition: transform 0.2s ease-in-out;
        }
        .cake-card:hover {
            transform: scale(1.02);
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <h1 class="text-center mb-4">🎂 Welcome to Cake Order Shop</h1>

    <!-- فرم دریافت کد پستی -->
    <form action="index.php" method="POST" class="mb-4">
        <label for="postal_code" class="form-label">Enter Your Dutch Postal Code:</label>
        <div class="input-group w-50">
            <input type="text" name="postal_code" required class="form-control" placeholder="e.g. 1011AB">
            <button type="submit" class="btn btn-primary">Find Cakes</button>
        </div>
    </form>

    <?= $branch_info ?>
    <?= $message ?>

    <?php if (!empty($cakes)): ?>
        <div class="row g-4">
            <?php foreach ($cakes as $cake): ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                    <div class="card cake-card h-100 shadow-sm">
                        <?php if (!empty($cake['image_url'])): ?>
                            <img src="<?= htmlspecialchars($cake['image_url']) ?>" class="card-img-top cake-thumbnail" alt="<?= htmlspecialchars($cake['name']) ?>">
                        <?php endif; ?>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($cake['name']) ?></h5>
                            <p class="card-text text-muted"><?= nl2br(htmlspecialchars($cake['description'])) ?></p>
                            <ul class="list-unstyled mb-3">
                                <?php if ($cake['pricing_type'] === 'multi'): ?>
                                    <?php if (!is_null($cake['price_per_slice'])): ?>
                                        <li><strong>Per Slice:</strong> €<?= number_format($cake['price_per_slice'], 2) ?></li>
                                    <?php endif; ?>
                                    <?php if (!is_null($cake['price_half'])): ?>
                                        <li><strong>Half Cake:</strong> €<?= number_format($cake['price_half'], 2) ?></li>
                                    <?php endif; ?>
                                    <?php if (!is_null($cake['base_price'])): ?>
                                        <li><strong>Whole Cake:</strong> €<?= number_format($cake['base_price'], 2) ?></li>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <li><strong>Price:</strong> €<?= number_format($cake['base_price'], 2) ?></li>
                                <?php endif; ?>
                            </ul>
                            <a href="order.php?cake_id=<?= $cake['id'] ?>" class="btn btn-success mt-auto w-100">
                                <i class="bi bi-cart-fill"></i> Order Now
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script src="assets/bootstrap.bundle.min.js"></script>
</body>
</html>
