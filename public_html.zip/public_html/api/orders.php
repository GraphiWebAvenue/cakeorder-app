<?php
header('Content-Type: application/json');
require '../includes/config.php';

// گرفتن داده‌های JSON
$data = json_decode(file_get_contents('php://input'), true);

// اعتبارسنجی اولیه
$required = ['user_id', 'cake_id', 'branch_id', 'delivery_method', 'quantity', 'price_type', 'total_price'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        echo json_encode(['success' => false, 'message' => "$field is required."]);
        exit;
    }
}

// مقادیر
$user_id = $data['user_id'];
$cake_id = $data['cake_id'];
$branch_id = $data['branch_id'];
$delivery_method = $data['delivery_method'];
$price_type = $data['price_type'];
$quantity = (int) $data['quantity'];
$total_price = (float) $data['total_price'];
$order_date = date('Y-m-d H:i:s');

// تاریخ و ساعت فقط برای Pickup
$delivery_date = ($delivery_method === 'pickup') ? ($data['delivery_date'] ?? null) : null;
$delivery_time = ($delivery_method === 'pickup') ? ($data['delivery_time'] ?? null) : null;

// آدرس فقط برای Delivery
$province = ($delivery_method === 'delivery') ? ($data['province'] ?? '') : '';
$city = ($delivery_method === 'delivery') ? ($data['city'] ?? '') : '';
$street_address = ($delivery_method === 'delivery') ? ($data['street_address'] ?? '') : '';
$house_number = ($delivery_method === 'delivery') ? ($data['house_number'] ?? '') : '';
$extra_details = ($delivery_method === 'delivery') ? ($data['extra_details'] ?? '') : '';

try {
    $stmt = $pdo->prepare("
        INSERT INTO orders (
            user_id, cake_id, branch_id, delivery_method, delivery_date, delivery_time, 
            total_price, status, order_date,
            province, city, street_address, house_number, extra_details
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $user_id, $cake_id, $branch_id, $delivery_method,
        $delivery_date, $delivery_time, $total_price, $order_date,
        $province, $city, $street_address, $house_number, $extra_details
    ]);

    echo json_encode(['success' => true, 'message' => 'Order placed successfully.']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
