<?php
header('Content-Type: application/json');
require '../includes/config.php';

$data = json_decode(file_get_contents('php://input'), true);
$branch_id = $data['branch_id'] ?? null;

if (!$branch_id) {
    echo json_encode(['message' => 'Branch ID is required.']);
    exit;
}

$stmt = $pdo->prepare("
    SELECT 
        c.id, 
        c.name, 
        c.description, 
        c.base_price, 
        c.price_per_slice, 
        c.price_half, 
        c.pricing_type, 
        c.image_url
    FROM cakes c
    JOIN cake_branch cb ON c.id = cb.cake_id
    WHERE cb.branch_id = ?
");
$stmt->execute([$branch_id]);
$cakes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$cakes) {
    echo json_encode(['message' => 'No cakes found for this branch.']);
    exit;
}

// آماده‌سازی داده‌ها برای JSON خروجی
foreach ($cakes as &$cake) {
    $cake['base_price'] = isset($cake['base_price']) ? (float)$cake['base_price'] : 0;
    $cake['price_per_slice'] = isset($cake['price_per_slice']) ? (float)$cake['price_per_slice'] : 0;
    $cake['price_half'] = isset($cake['price_half']) ? (float)$cake['price_half'] : 0;
    $cake['is_per_slice_enabled'] = ($cake['pricing_type'] === 'multi') ? 1 : 0;
}
unset($cake);

echo json_encode(['cakes' => $cakes]);
