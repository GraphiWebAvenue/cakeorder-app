<?php
require '../includes/config.php';
header('Content-Type: application/json');

// بررسی متد درخواست
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 🔒 بخش JWT فعلاً غیرفعاله (برای تست)
    /*
    if (!isset($_SERVER['HTTP_AUTHORIZATION'])) {
        echo json_encode(['message' => 'Authorization token is missing']);
        exit();
    }

    $authorization_header = $_SERVER['HTTP_AUTHORIZATION'];
    $token = str_replace('Bearer ', '', $authorization_header);

    $secret_key = 'your_secret_key';
    try {
        $decoded = JWT::decode($token, $secret_key, array('HS256'));
    } catch (Exception $e) {
        echo json_encode(['message' => 'Invalid or expired token']);
        exit();
    }
    */

    // دریافت کد پستی از بدنه درخواست
    $data = json_decode(file_get_contents("php://input"));
    $postal_code = htmlspecialchars($data->postal_code, ENT_QUOTES, 'UTF-8');

    // تبدیل به lowercase برای جستجوی غیرحساس به حروف بزرگ/کوچک
    $stmt = $pdo->prepare("SELECT latitude, longitude FROM postal_codes WHERE LOWER(postal_code) = LOWER(?) LIMIT 1");
    $stmt->execute([$postal_code]);
    $user_location = $stmt->fetch();

    if ($user_location) {
        // جستجوی نزدیک‌ترین شعبه با Haversine
        $stmt = $pdo->prepare("
            SELECT id, name, address, city, latitude, longitude,
                ROUND(
                    (6371 * ACOS(
                        COS(RADIANS(?)) * COS(RADIANS(latitude)) *
                        COS(RADIANS(longitude) - RADIANS(?)) +
                        SIN(RADIANS(?)) * SIN(RADIANS(latitude))
                    )),
                2) AS distance
            FROM branches
            ORDER BY distance ASC
            LIMIT 1
        ");
        $stmt->execute([
            $user_location['latitude'],
            $user_location['longitude'],
            $user_location['latitude']
        ]);
        $nearest_branch = $stmt->fetch();

        if ($nearest_branch) {
            echo json_encode(['branches' => [$nearest_branch]]);
        } else {
            echo json_encode(['message' => 'No branches found for this postal code.']);
        }
    } else {
        echo json_encode(['message' => 'Invalid postal code.']);
    }
} else {
    echo json_encode(['message' => 'Invalid request method.']);
}
