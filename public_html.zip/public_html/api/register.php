<?php
header('Content-Type: application/json');
require '../includes/config.php';

$data = json_decode(file_get_contents('php://input'), true);

$name = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

if (!$name || !$email || !$password) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit;
}

// بررسی وجود ایمیل در دیتابیس
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'message' => 'Email already exists.']);
    exit;
}

// رمزنگاری پسورد
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

// ثبت کاربر
$stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
$stmt->execute([$name, $email, $hashedPassword]);

$userId = $pdo->lastInsertId();

// ارسال اطلاعات به فرانت بدون پسورد
echo json_encode([
    'success' => true,
    'user' => [
        'id' => $userId,
        'name' => $name,
        'email' => $email
    ]
]);
