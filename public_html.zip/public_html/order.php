<?php
require 'includes/config.php';
session_start();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if (!isset($_GET['cake_id']) || empty($_GET['cake_id'])) {
    die("Invalid cake selection.");
}

$cake_id = $_GET['cake_id'];
$stmt = $pdo->prepare("SELECT * FROM cakes WHERE id = ?");
$stmt->execute([$cake_id]);
$cake = $stmt->fetch();
if (!$cake) die("Cake not found.");

$stmt = $pdo->prepare("SELECT branches.id, branches.name FROM branches 
                      JOIN cake_branch ON branches.id = cake_branch.branch_id 
                      WHERE cake_branch.cake_id = ?
                      ORDER BY branches.id ASC LIMIT 1");
$stmt->execute([$cake_id]);
$branch = $stmt->fetch();
if (!$branch) die("No available branches for this cake.");

$order_success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['user_id'])) {
    $delivery_method = $_POST['delivery_method'];
    $delivery_date = $_POST['delivery_date'] ?? null;
    $delivery_time = $_POST['delivery_time'] ?? null;
    $quantity = intval($_POST['quantity']);
    $selected_type = $_POST['price_type'] ?? 'whole';
    $user_id = $_SESSION['user_id'];
    $order_date = date('Y-m-d H:i:s');

    $province = $_POST['province'] ?? '';
    $city = $_POST['city'] ?? '';
    $street_address = $_POST['street_address'] ?? '';
    $house_number = $_POST['house_number'] ?? '';
    $extra_details = $_POST['extra_details'] ?? '';

    $price_per_unit = 0;
    if ($cake['pricing_type'] === 'multi') {
        if ($selected_type === 'slice') $price_per_unit = (float) $cake['price_per_slice'];
        elseif ($selected_type === 'half') $price_per_unit = (float) $cake['price_half'];
        else $price_per_unit = (float) $cake['base_price'];
    } else {
        $price_per_unit = (float) $cake['base_price'];
    }

    $total_price = $quantity * $price_per_unit;

    $stmt = $pdo->prepare("INSERT INTO orders 
        (user_id, cake_id, branch_id, delivery_date, delivery_time, delivery_method, total_price, status, order_date, province, city, street_address, house_number, extra_details)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?)");

    $stmt->execute([
        $user_id, $cake_id, $branch['id'],
        $delivery_date, $delivery_time, $delivery_method,
        $total_price, $order_date,
        $province, $city, $street_address, $house_number, $extra_details
    ]);

    $order_success_message = "<div class='alert alert-success mt-3'>Order placed successfully!</div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Cake</title>
    <link rel="stylesheet" href="assets/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <script>
        function updateTotal() {
            const pricingType = "<?= $cake['pricing_type'] ?>";
            let price = <?= (float) $cake['base_price'] ?>;
            const quantity = parseInt(document.getElementById("quantity").value) || 0;

            if (pricingType === 'multi') {
                const selected = document.getElementById("price_type").value;
                if (selected === 'slice') price = <?= (float) $cake['price_per_slice'] ?>;
                else if (selected === 'half') price = <?= (float) $cake['price_half'] ?>;
                else price = <?= (float) $cake['base_price'] ?>;
            }

            const total = price * quantity;
            document.getElementById("total_price").innerText = "Total: €" + total.toFixed(2);
        }

        function toggleFields() {
            const method = document.getElementById("delivery_method").value;
            const addressFields = document.getElementById("address-fields");
            const dateTimeFields = document.getElementById("datetime-fields");

            if (method === "delivery") {
                addressFields.style.display = "block";
                dateTimeFields.style.display = "none";
            } else if (method === "pickup") {
                addressFields.style.display = "none";
                dateTimeFields.style.display = "block";
            } else {
                addressFields.style.display = "none";
                dateTimeFields.style.display = "none";
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
            const quantityInput = document.getElementById("quantity");
            const priceType = document.getElementById("price_type");
            const deliveryMethod = document.getElementById("delivery_method");

            if (quantityInput) quantityInput.addEventListener("input", updateTotal);
            if (priceType) priceType.addEventListener("change", updateTotal);
            if (deliveryMethod) deliveryMethod.addEventListener("change", toggleFields);

            updateTotal();
            toggleFields();
        });
    </script>
</head>
<body>
<div class="container mt-4">
    <h1 class="text-center mb-4">Order: <?= htmlspecialchars($cake['name']) ?></h1>

    <?php if (isset($_SESSION['user_id'])): ?>
        <?= $order_success_message ?>

        <div class="card mb-4">
            <div class="card-body">
                <h5>Pricing:</h5>
                <ul class="mb-0">
                    <?php if ($cake['pricing_type'] === 'multi'): ?>
                        <li><strong>Per Slice:</strong> €<?= number_format($cake['price_per_slice'], 2) ?></li>
                        <li><strong>Half Cake:</strong> €<?= number_format($cake['price_half'], 2) ?></li>
                        <li><strong>Whole Cake:</strong> €<?= number_format($cake['base_price'], 2) ?></li>
                    <?php else: ?>
                        <li><strong>Price:</strong> €<?= number_format($cake['base_price'], 2) ?></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <form method="POST" class="card p-4 mb-4">
            <div class="row mb-3">
                <?php if ($cake['pricing_type'] === 'multi'): ?>
                    <div class="col-md-6">
                        <label for="price_type" class="form-label">Order Type:</label>
                        <select name="price_type" id="price_type" class="form-select" required>
                            <option value="slice">Per Slice</option>
                            <option value="half">Half Cake</option>
                            <option value="whole">Whole Cake</option>
                        </select>
                    </div>
                <?php else: ?>
                    <input type="hidden" name="price_type" value="whole">
                <?php endif; ?>

                <div class="col-md-6">
                    <label for="quantity" class="form-label">Quantity:</label>
                    <input type="number" name="quantity" id="quantity" class="form-control" min="1" value="1" required>
                </div>
            </div>

            <div class="mb-3 text-end">
                <h5 id="total_price" class="text-primary">Total: €0.00</h5>
            </div>

            <div class="mb-3">
                <label for="delivery_method" class="form-label">Delivery Method:</label>
                <select name="delivery_method" id="delivery_method" class="form-select" required>
                    <option value="">-- Select Delivery Method --</option>
                    <option value="pickup">Pickup</option>
                    <option value="delivery">Delivery</option>
                </select>
            </div>

            <div id="datetime-fields" style="display: none;">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="delivery_date" class="form-label">Delivery Date:</label>
                        <input type="date" name="delivery_date" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="delivery_time" class="form-label">Delivery Time:</label>
                        <input type="time" name="delivery_time" class="form-control">
                    </div>
                </div>
            </div>

            <div id="address-fields" style="display: none;">
                <div class="row mb-2">
                    <div class="col-md-6">
                        <label>Province</label>
                        <input type="text" name="province" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label>City</label>
                        <input type="text" name="city" class="form-control">
                    </div>
                </div>
                <label>Street Address</label>
                <input type="text" name="street_address" class="form-control mb-2">
                <label>House Number</label>
                <input type="text" name="house_number" class="form-control mb-2">
                <label>Additional Details</label>
                <textarea name="extra_details" class="form-control mb-2"></textarea>
            </div>

            <button type="submit" name="order" class="btn btn-success mt-3 w-100">
                <i class="bi bi-cart-fill"></i> Place Order
            </button>
        </form>
    <?php else: ?>
        <div class="alert alert-warning text-center">
            Please log in or register to place an order.
        </div>
    <?php endif; ?>
</div>

<script src="assets/bootstrap.bundle.min.js"></script>
</body>
</html>
