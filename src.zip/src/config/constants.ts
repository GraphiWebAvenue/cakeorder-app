// src/config/constants.ts
export const API_BASE_URL = 'https://cakeorder.shop/api';
